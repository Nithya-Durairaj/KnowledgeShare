import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppyWatermarkPage } from './appy-watermark.page';

describe('AppyWatermarkPage', () => {
  let component: AppyWatermarkPage;
  let fixture: ComponentFixture<AppyWatermarkPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppyWatermarkPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppyWatermarkPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
