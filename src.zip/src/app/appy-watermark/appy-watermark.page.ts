import { WatermarkServicesService } from './../service/watermark-services.service';
import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import * as watermark from 'watermarkjs';

@Component({
  selector: 'app-appy-watermark',
  templateUrl: './appy-watermark.page.html',
  styleUrls: ['./appy-watermark.page.scss'],
})
export class AppyWatermarkPage implements OnInit {
  originalImage: any;
  splitChar: any;
  imageData = null;
  displayImage = null;
  blobImage = null;
  originalImage1: any;
  originalImage2: any;
  originalImage3: any;
  originalImage4: any;
  @ViewChild('Template2' , {static: false}) waterMarkImage2: ElementRef;
  @ViewChild('Template1' , {static: false}) waterMarkImage1: ElementRef;
  @ViewChild('Template3' , {static: false}) waterMarkImage3: ElementRef;
  @ViewChild('Template4' , {static: false}) waterMarkImage4: ElementRef;
  constructor(public waterMarkService: WatermarkServicesService) {
    console.log('constructor invked');
    this.originalImage = this.waterMarkService.getbOriginalImage();
    console.log('original image2--->' + this.originalImage);
    console.log('addTextWatermark starts');
    watermark([this.originalImage])
      .image(watermark.text.center('Tempalte1', '260px Arial', '#fff', 0.4))
      .then(img => {
        console.log('template1-->' + img.src );
        this.originalImage1 = img.src; });
    console.log('end1');
    watermark([this.originalImage])
      .image(watermark.text.lowerRight('Tempalte2', '280px serif', '#fff', 0.5))
      .then(img => {
        this.originalImage2 = img.src; });
    console.log('end2');
    watermark([this.originalImage])
      .image(watermark.text.lowerLeft('Tempalte3', '260px Arial', '#fff', 0.4))
      .then(img => {
        this.originalImage3 = img.src; });
    console.log('end3');
    watermark([this.originalImage])
      .image(watermark.text.upperLeft('Tempalte4', '260px Arial', '#fff', 0.4))
      .then(img => {
        this.originalImage4 = img.src; });
    console.log('end4');
  }
  ngOnInit() {
  }

}
