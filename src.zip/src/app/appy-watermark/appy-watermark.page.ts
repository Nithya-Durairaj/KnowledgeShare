import { PhotoLibrary } from '@ionic-native/photo-library/ngx';
import { AlertController } from '@ionic/angular';
import { WatermarkServicesService } from './../service/watermark-services.service';
import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import * as watermark from 'watermarkjs';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
declare var cordova;
@Component({
  selector: 'app-appy-watermark',
  templateUrl: './appy-watermark.page.html',
  styleUrls: ['./appy-watermark.page.scss'],
})
export class AppyWatermarkPage implements OnInit {
  originalImage = null;
  splitChar: any;
  imageData = null;
  displayImage = null;
  blobImage = null;
  originalImage1: any;
  originalImage2: any;
  originalImage3: any;
  originalImage4: any;
  WatermarkText = null;
  tempalte1: any;
  tempalte2: any;
  tempalte3: any;
  tempalte4: any;
  dirPath: any;
  fontStyle: any;
  fontDropDown: any;
  err: any;
  setFont: any;
  drodownSelected = false;
  noofTemplate = [
    {id: 'center', imageName: 'originalImage1', imageBase: ''},
    {id: 'Lower Left', imageName: 'originalImage2', imageBase: ''},
    {id: 'Lower Right', imageName: 'originalImage3', imageBase: ''},
    {id: 'Template4', imageName: 'originalImage4', imageBase: ''},
    {id: 'Template5', imageName: 'originalImage5', imageBase: ''}
  ];
  sliderConfig = {
    slidesPerView: 1.2,
    spaceBetween: 8,
    centeredSlides: true
  };
  constructor(public waterMarkService: WatermarkServicesService, public transfer: FileTransfer, private files: File,
              public alertCtrl: AlertController, public photoLibrary: PhotoLibrary) {
 this.fontDropDown = this.waterMarkService.fontFmaily;
 this.fontStyle = 'Default';
 this.setFont = 'Merienda-Bold'
  }
  ngOnInit() {
  }

  
  saveImage(imageName: string) {
    try{
      this.waterMarkService.presentLoading();
      console.log(cordova.file);
      let storageDirectory = '';
      storageDirectory = cordova.file.externalDataDirectory + 'WaterMarkApp/';
      this.dirPath = storageDirectory;
      let imageSrc = '';
      if (imageName == 'originalImage1') {
       imageSrc = this.originalImage1.split(',');
        } else if (imageName == 'originalImage2') {
         imageSrc = this.originalImage2.split(',');
        } else if (imageName == 'originalImage3') {
        imageSrc = this.originalImage3.split(',');
        } else if (imageName == 'originalImage4') {
          imageSrc = this.originalImage4.split(',');
      }
      let displayImage = imageSrc[1];
      let uri = encodeURI('data:' + 'image/png' + ';base64,' + displayImage);
      console.log('storageDirectory->' + storageDirectory);
      var fileURL = storageDirectory + 'Image.png'.replace(/ /g, '%20');
      const fileTransfer = this.transfer.create();
      fileTransfer.download(uri, fileURL).then((success) => {
        console.log('storageDirectory1->' + JSON.stringify(success));
        this.waterMarkService.dismissLoading();
    }, error => {
        this.waterMarkService.dismissLoading();
        console.log('this.originalImage1- error->' + JSON.stringify(error));
    });
      this.saveImagesToGallery();
  } catch (e) {
    console.log('error in getpicture'  + e);
    this.waterMarkService.dismissLoading();
  }
}

async presentAlert() {
  try{
  const alert = await this.alertCtrl.create({
    header: 'Success',
    message: this.err,
    buttons: ['OK']
  });
  await alert.present();
} catch (e) {
  console.log('error in getpicture'  + e);
}
}
ionViewLoaded() {

  setTimeout(() => {
    this.WatermarkText.setFocus();
  }, 150);

}
ApplyWatermark() {
  try{
    this.waterMarkService.presentLoading();
    this.drodownSelected = false;
    this.originalImage = this.waterMarkService.getbOriginalImage();
    console.log('original image2--->' + this.originalImage);
    console.log('Watermark text--->' + this.WatermarkText);
    this.fontStyle = this.waterMarkService.selectedFontFamily;
    console.log('selected font text--->' + this.fontStyle);
    if (this.fontStyle == 'Default') {
      this.fontStyle = 'Merienda-Bold';
    }
    watermark([this.originalImage])
    .image(watermark.text.center(this.WatermarkText, '260px ' + this.fontStyle, '#fff', 0.4))
    .then(img => {
      this.originalImage1 = img.src;
      this.noofTemplate[0].imageBase = img.src;
    });
    console.log('end1');
    watermark([this.originalImage])
    .image(watermark.text.lowerRight(this.WatermarkText, '280px ' + this.fontStyle, '#fff', 0.5))
    .then(img => {
      this.originalImage2 = img.src; 
      this.noofTemplate[1].imageBase = img.src;
      });
    console.log('end2');
    watermark([this.originalImage])
    .image(watermark.text.lowerLeft(this.WatermarkText, '260px ' +  this.fontStyle, '#fff', 0.4))
    .then(img => {
      this.originalImage3 = img.src;
      this.noofTemplate[2].imageBase = img.src;
      });
    console.log('end3');
    var ul = watermark.text.upperLeft;
    watermark(['/img/wolf.jpg'])
          .image(ul('watermark.js', '48px Josefin Slab', '#fff', 0.5, 48))
          .then(function (img) {
            this.originalImage3 = img.src;
            this.noofTemplate[2].imageBase = img.src;
           });
    this.waterMarkService.dismissLoading();
    console.log('end4');
    ///Upper Right
    this.waterMarkService.dismissLoading();
        } catch (e)
    {
      this.waterMarkService.dismissLoading();
      console.log('ApplyWatermark-->' + e);
    }

}
saveImagesToGallery() {
  try {
  cordova.plugins.photoLibrary.requestAuthorization({read: true, write: true});
  this.photoLibrary.saveImage(this.dirPath + 'Image.png', 'watermarkApp').then((entry => {
    console.log('download complete: ' + JSON.stringify(entry));
    this.err = 'Watermark image stored successfuly';
    this.presentAlert();
  }),
  (error) => {
    // handle error
    this.presentAlert();
    this.err = error;
    console.log('download complete: ' + error);
  });
} catch (e) {
  console.log('download complete: ' + e);
}
}

setFontfamily()
{
  console.log('selcted family-->'+this.fontStyle);
  this.setFont = this.fontStyle;
}

dropDownSelect(){
  this.drodownSelected = true;
}
}
