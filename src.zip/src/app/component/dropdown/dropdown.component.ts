import { WatermarkServicesService } from './../../service/watermark-services.service';
import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss'],
})
export class DropdownComponent implements OnInit {

  fontStyle: any;
  fontColor = 'primary';
  myimage = '../../assets/icon/uncheck.svg';
  visible = false;
  itemClicked: any;
  constructor( public watermarkService: WatermarkServicesService) {
    this.fontStyle = this.watermarkService.fontFmaily;
  }
  toggle(id, idlabel, fontColorvalue) {
    console.log('iconChecKmark FRM' + id);
    console.log('idlabel FRM' + idlabel);
    this.itemClicked = idlabel;
    this.visible = !this.visible;
    this.watermarkService.selectedFontFamily = id;
  }
  ngOnInit() {}
}
