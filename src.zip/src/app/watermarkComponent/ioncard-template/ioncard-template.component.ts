import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ioncard-template',
  templateUrl: './ioncard-template.component.html',
  styleUrls: ['./ioncard-template.component.scss'],
})
export class IoncardTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
