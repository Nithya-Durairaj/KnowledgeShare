import { TestBed } from '@angular/core/testing';

import { WatermarkServicesService } from './watermark-services.service';

describe('WatermarkServicesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WatermarkServicesService = TestBed.get(WatermarkServicesService);
    expect(service).toBeTruthy();
  });
});
