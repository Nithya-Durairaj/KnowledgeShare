import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WatermarkServicesService {

  originalImage: any;
  billingData: any;
  constructor() { }
  getbOriginalImage() {
    return this.originalImage;
  }
}
