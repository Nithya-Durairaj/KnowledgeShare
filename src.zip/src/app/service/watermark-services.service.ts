import { LoadingController } from '@ionic/angular';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WatermarkServicesService {

  originalImage: any;
  isLoading = false;
  constructor(public loadingController: LoadingController) { }
  getbOriginalImage() {
    return this.originalImage;
  }
  async presentLoading() {
    try{
    this.isLoading = true;
    return await this.loadingController.create({
      duration: 5000,
    }).then(a => {
      a.present().then(() => {
        console.log('presented');
        if (!this.isLoading) {
          a.dismiss().then(() => console.log('abort presenting'));
        }
      });
    });
  } catch (e) {
    console.log('error in getpicture'  + e);
  }
  }

  async dismissLoading() {
    try{
    this.isLoading = false;
    return await this.loadingController.dismiss().then(() => console.log('dismissed'));
  } catch (e) {
    console.log('error in getpicture'  + e);
  }
  }
}
