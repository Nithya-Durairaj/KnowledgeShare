import { LoadingController } from '@ionic/angular';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WatermarkServicesService {

  originalImage: any;
  isLoading = false;
  selectedFontFamily: any;
  fontFmaily = [{id: 'Merienda-Bold'},
    {id: 'LucianSchoenschrift-CAT'},
    {id: 'KaushanScript-Regular'},
    {id: 'Echo-Deco' },
    {id: 'Eclipser'},
    {id: 'EDB-Indians'},
    {id: 'ElGar'},
    {id: 'EDB-Sweatin-It'},
    {id: 'Endeavour-forever'},
    {id: 'English-Vivace-BT'},
    {id: 'Quilted-Indian'},
    {id: 'Merienda-Regular'}];
  constructor(public loadingController: LoadingController) { }
  getbOriginalImage() {
    return this.originalImage;
  }
  async presentLoading() {
    try{
    this.isLoading = true;
    return await this.loadingController.create({
      duration: 5000,
    }).then(a => {
      a.present().then(() => {
        console.log('presented');
        if (!this.isLoading) {
          a.dismiss().then(() => console.log('abort presenting'));
        }
      });
    });
  } catch (e) {
    console.log('error in getpicture'  + e);
  }
  }

  async dismissLoading() {
    try{
    this.isLoading = false;
    return await this.loadingController.dismiss().then(() => console.log('dismissed'));
  } catch (e) {
    console.log('error in getpicture'  + e);
  }
  }
}
