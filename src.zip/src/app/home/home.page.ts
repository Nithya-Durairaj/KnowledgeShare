import { WatermarkServicesService } from './../service/watermark-services.service';
import { Camera, CameraOptions  } from '@ionic-native/camera/ngx';
import { Component, ViewChild, ElementRef } from '@angular/core';
import * as watermark from 'watermarkjs';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
 // @ViewChild('previewimage') waterMarkImage: ElementRef;
 @ViewChild('previewimage' , {static: false}) waterMarkImage: ElementRef;
  originalImage = null;
  blobImage = null;
  imgData = null;
  constructor(public navCtrl: NavController, private camera: Camera, public router: Router,
              public watermarkservice: WatermarkServicesService) {}
  captureImage() {
    console.log('captureImage starts');
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      sourceType: this.camera.PictureSourceType.PHOTOLIBRARY
    }

    this.camera.getPicture(options).then((imageData) => {
      this.originalImage = 'data:image/jpeg;base64,' + imageData;
      console.log('original imageT55-->'  + this.originalImage);
      this.watermarkservice.originalImage = this.originalImage;
      fetch(this.originalImage)
        .then(res => res.blob())
        .then(blob => {
          this.blobImage = blob;
        });
    }, (err) => {
      // Handle error
    });
  }

  addImageWatermark() {
    console.log('addImageWatermark starts');
    watermark([this.blobImage, 'assets/imgs/academy.png'])
      .image(watermark.image.lowerRight(0.6))
      .then(img => {
        this.waterMarkImage.nativeElement.src = img.src;
      });
  }

  addTextWatermark() {
    console.log('addTextWatermark starts');
    watermark([this.blobImage])
      .image(watermark.text.center('Nithya test', '260px Arial', '#fff', 0.4))
      .then(img => {
        this.waterMarkImage.nativeElement.src = img.src; });
    this.router.navigate(['/appy-watermark']);
    console.log('end');
  }
}
